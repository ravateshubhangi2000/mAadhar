package com.example.mAdharApp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@EntityScan(basePackages = "com.mAadhar.pojo")
@EnableJpaRepositories(basePackages = "com.mAadhar.repository")

@SpringBootApplication
public class MAdhar1Application {

	public static void main(String[] args) {
		SpringApplication.run(MAdhar1Application.class, args);
		System.out.println("Server Running on 9191");
	}

}
